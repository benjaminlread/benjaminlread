
November 18, 2008

Thank you for your interest in our work.

This collection contains replication files for:

Benjamin L. Read and Ethan Michelson,
"Mediating the Mediation Debate: Conflict Resolution and the Local State in China"
Journal of Conflict Resolution
Vol. 52, No. 5 (October 2008), pp. 737-764

The authors' contact information is provided in FullTables.doc, or visit http://benread.net.
More information about the survey data can be found in the appendix (pp. 760-761) of the published article.

-------------------------------------------------------------------------------
Data:

The authors request that interested scholars contact them and obtain permission before using this data for publication.
The data is provided here in Stata format. Stata version 9 was used in the production of this article.
Replication of Table 6 and Figure 1 requires installation of the SPost post-regression analysis commands by J. Scott Long and Jeremy Freese (http://www.indiana.edu/~jslsoc/spost.htm).

-------------------------------------------------------------------------------

Files in this package:

readme.txt                This file
Mediation_FullTables.doc  A supplement to the published article containing unabridged tables
ReplicationOverview.xls   1) Shows which datasets produce which tables/figure and
                          2) Compares the abridged tables in the published article with the full ones in "FullTables.doc"

bjhh.dta                  Beijing dataset, household level; each observation is a respondent
bjhh-rep.do               Stata do-file to use with this dataset to replicate the relevant results (Tables A, B, 1)

bjdisp.dta                Beijing dataset; each observation is a dispute extracted from the original Beijing survey
bjdisp-rep.do             Stata do-file to use with this dataset to replicate the relevant results (Tables 3, 7)

rurhh.dta                 Rural dataset, household level; each observation is a respondent
rurhh-rep.do              Stata do-file to use with this dataset to replicate the relevant results (Tables A, B, 2)

rurdisp.dta               Rural dataset; each observation is a dispute extracted from the original rural survey
rurdisp-rep1.do           Stata do-file to use with this dataset to replicate the relevant results (Table 4)
rurdisp-rep2.do           Stata do-file to use with this dataset to replicate the relevant results (Tables 5, 6, 7)
rurdisp-rep3.do           Stata do-file to use with this dataset to replicate the relevant results (Figure 1); rurdisp-rep2.do must be run first

